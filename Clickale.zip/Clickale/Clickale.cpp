#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

class Crosshair {
public:
    Crosshair() {
        if (!texturaCrosshair.loadFromFile("crosshair.png")) {}
        spriteCrosshair.setTexture(texturaCrosshair);
        spriteCrosshair.setOrigin(64, 64);
    }
    Sprite getSprite() {
        return spriteCrosshair;
    }
    void posCrosshair(float x, float y) {
        spriteCrosshair.setPosition(x, y);
    }
private:
    Texture texturaCrosshair;
    Sprite spriteCrosshair;
};

class Alien {
public:
    Alien() {
        if (!texturaAlien.loadFromFile("et.png")) {}
        spriteAlien.setTexture(texturaAlien);
        spriteAlien.setScale(0.2f, 0.2f);
    }
    void draw(RenderWindow& App) {
        App.draw(spriteAlien);
    }
    void posAliens() {
        float x = float(rand() % (800 - int(spriteAlien.getGlobalBounds().width)));
        float y = float(rand() % (600 - int(spriteAlien.getGlobalBounds().height)));
        spriteAlien.setPosition(x, y);
    }
    bool click(int mouseX, int mouseY) {
        return spriteAlien.getGlobalBounds().contains(mouseX, mouseY);
    }
private:
    Texture texturaAlien;
    Sprite spriteAlien;
};

int main() {

    Event evt;
    Alien aliens[5];
    Crosshair crosshair;

    srand((time(NULL)));
    int aliensEliminados = 0;
    int aliensVivos = 0;

    RenderWindow App(VideoMode(800, 600), "Clickale");

    App.setMouseCursorVisible(false);

    while (App.isOpen() && aliensEliminados < 5) {
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Left) {
                    int mouseX = evt.mouseButton.x;
                    int mouseY = evt.mouseButton.y;
                    if (aliensVivos >= 0 && aliensVivos < 5) {
                        if (aliens[aliensVivos].click(mouseX, mouseY)) {
                            aliensVivos++;
                            aliensEliminados++;
                            if (aliensVivos < 5) {
                                aliens[aliensVivos].posAliens();
                            }
                        }
                    }
                }
            }
            crosshair.posCrosshair((Mouse::getPosition(App).x), (Mouse::getPosition(App).y));
            App.clear();
            if (aliensVivos < 5) {
                aliens[aliensVivos].draw(App);
            }
            App.draw(crosshair.getSprite());
            App.display();
        }
    }
    return 0;
}