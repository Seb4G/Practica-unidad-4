#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {

    Event evt;
    RenderWindow App(VideoMode(800, 600), "Cambiar ventana");

    while (App.isOpen()){
        while (App.pollEvent(evt)){
            switch (evt.type){
            case Event::Closed:
                App.close();
                break;
            case Event::Resized:
                if (evt.size.width < 100 || evt.size.height < 100){
                    evt.size.width = 100;
                    evt.size.height = 100;
                }
                if (evt.size.width > 1000 || evt.size.height > 1000){
                    evt.size.width = 1000;
                    evt.size.height = 1000;
                }
                App.setSize({evt.size.width, evt.size.height});
            }
        }
        App.clear();
        App.display();
    }
    return 0;
}
