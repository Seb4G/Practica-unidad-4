#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

int main() {

    Event evt;
    RenderWindow window(VideoMode(800, 600), "Cambiar ventana");

    while (window.isOpen()){
        while (window.pollEvent(evt)){
            switch (evt.type){
            case Event::Closed:
                window.close();
                break;
            case Event::Resized:
                if (evt.size.width < 100 || evt.size.height < 100){
                    evt.size.width = 100;
                    evt.size.height = 100;
                }
                if (evt.size.width > 1000 || evt.size.height > 1000){
                    evt.size.width = 1000;
                    evt.size.height = 1000;
                }
                window.setSize({evt.size.width, evt.size.height});
            }
        }
        window.clear();
        window.display();
    }
    return 0;
}
