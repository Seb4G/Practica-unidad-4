#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture textura;
Sprite sprite;
Sprite sprite2;
Sprite sprite3;
Sprite sprite4;

int main() {

    Event evt;
    textura.loadFromFile("rcircle.png");
    sprite.setTexture(textura);
    sprite.setPosition(675, 475);

    sprite2.setTexture(textura);
    sprite2.setPosition(0, 0);

    sprite3.setTexture(textura);
    sprite3.setPosition(675, 0);

    sprite4.setTexture(textura);
    sprite4.setPosition(0, 475);

    RenderWindow App(VideoMode(800, 600), "Mover puntos rojos");
    Vector2i antMousePos = Mouse::getPosition(App);

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::MouseMoved:
                Vector2i actMousePos = Mouse::getPosition(App);
                Vector2i difMouses = actMousePos - antMousePos;

                sprite.setPosition(sprite.getPosition().x + difMouses.x, sprite.getPosition().y + difMouses.y);
                sprite2.setPosition(sprite2.getPosition().x + difMouses.x, sprite2.getPosition().y + difMouses.y);
                sprite3.setPosition(sprite3.getPosition().x + difMouses.x, sprite3.getPosition().y + difMouses.y);
                sprite4.setPosition(sprite4.getPosition().x + difMouses.x, sprite4.getPosition().y + difMouses.y);

                antMousePos = actMousePos;
            }
        }
        App.clear();
        App.draw(sprite);
        App.draw(sprite2);
        App.draw(sprite3);
        App.draw(sprite4);
        App.display();
    }
    return 0;
}




