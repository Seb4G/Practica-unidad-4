#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture texturaCuad;
Texture texturaCirc;
Sprite spriteCuad;
Sprite spriteCirc;

int main() {

    texturaCuad.loadFromFile("cuad_yellow.png");
    spriteCuad.setTexture(texturaCuad);
    spriteCuad.setScale(0.2f, 0.2f);

    texturaCirc.loadFromFile("rcircleg.png");
    spriteCirc.setTexture(texturaCirc);
    spriteCirc.setScale(0.8f ,0.8f);

    float posX = 350.0f;
    float posY = 250.0f;
    bool cuadrado = true;

    Event evt;
    RenderWindow App(VideoMode(800, 600), "Mover figura");

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::KeyPressed:
                switch (evt.key.code) {
                case Keyboard::Space:
                    cuadrado = !cuadrado;
                    break;
                case Keyboard::Left:
                    if (posX > 0) {
                        posX -= 10;
                    }
                    break;
                case Keyboard::Right:
                    if (posX < 700) {
                        posX += 10;
                    }
                    break;
                case Keyboard::Up:
                    if (posY > 0) {
                        posY -= 10;
                    }
                    break;
                case Keyboard::Down:
                    if (posY < 500) {
                        posY += 10;
                    }
                    break;
                }
                break;
            }
        }
        App.clear();
        if (cuadrado){
            spriteCuad.setPosition(posX, posY);
            App.draw(spriteCuad);
        }
        else{
            spriteCirc.setPosition(posX, posY);
            App.draw(spriteCirc);
        }
        App.display();
    }
    return 0;
}