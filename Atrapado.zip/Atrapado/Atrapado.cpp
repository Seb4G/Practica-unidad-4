#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture texturaCuad;
Texture texturaCirc;
Sprite spriteCuad;
Sprite spriteCirc;

int main() {
    Event evt;
    texturaCuad.loadFromFile("cuad_yellow.png");
    spriteCuad.setTexture(texturaCuad);
    spriteCuad.setScale(0.2f, 0.2f);
    texturaCirc.loadFromFile("rcircleg.png");
    spriteCirc.setTexture(texturaCirc);
    spriteCirc.setScale(0.8f ,0.8f);

    float posX = 350.0f;
    float posY = 250.0f;
    bool cuadrado = true;
    RenderWindow window(VideoMode(800, 600), "Mover figura");

    while (window.isOpen()) {
        while (window.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                window.close();
                break;
            case Event::KeyPressed:
                switch (evt.key.code) {
                case Keyboard::Space:
                    cuadrado = !cuadrado;
                    break;
                case Keyboard::Left:
                    if (posX > 0) {
                        posX -= 5;
                    }
                    break;
                case Keyboard::Right:
                    if (posX < 700) {
                        posX += 5;
                    }
                    break;
                case Keyboard::Up:
                    if (posY > 0) {
                        posY -= 5;
                    }
                    break;
                case Keyboard::Down:
                    if (posY < 500) {
                        posY += 5;
                    }
                    break;
                }
                break;
            }
        }
        window.clear();
        if (cuadrado) {
            spriteCuad.setPosition(posX, posY);
            window.draw(spriteCuad);
        }
        else {
            spriteCirc.setPosition(posX, posY);
            window.draw(spriteCirc);
        }
        window.display();
    }
    return 0;
}