#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture texturaRoja;
Texture texturaAzul;
Sprite spriteCirculo;

int main() {

    Event evt;
    texturaRoja.loadFromFile("rcircle.png");
    texturaAzul.loadFromFile("rcircleb.png");

    RenderWindow App(VideoMode(800, 600), "A�adir circulos");

    while (App.isOpen()) {
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Left) {
                    spriteCirculo.setTexture(texturaRoja);
                    spriteCirculo.setOrigin(64, 64);
                    spriteCirculo.setPosition(evt.mouseButton.x, evt.mouseButton.y);
                }
                else if (evt.mouseButton.button == Mouse::Right) {
                    spriteCirculo.setTexture(texturaAzul);
                    spriteCirculo.setOrigin(64, 64);
                    spriteCirculo.setPosition(evt.mouseButton.x, evt.mouseButton.y);
                }
            }
        }
        App.draw(spriteCirculo);
        App.display();
    }
    return 0;
}