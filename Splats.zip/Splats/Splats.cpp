#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture texturaRoja;
Texture texturaAzul;
Sprite spriteCirculo;

int main() {
    Event evt;
    texturaRoja.loadFromFile("rcircle.png");
    texturaAzul.loadFromFile("rcircleb.png");

    RenderWindow window(VideoMode(800, 600), "A�adir circulos");

    while (window.isOpen()) {
        while (window.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                window.close();
                break;
            case Event::MouseButtonPressed:
                if (evt.mouseButton.button == Mouse::Left) {
                    spriteCirculo.setTexture(texturaRoja);
                    spriteCirculo.setOrigin(texturaRoja.getSize().x/2, texturaRoja.getSize().y/2);
                    spriteCirculo.setPosition(evt.mouseButton.x, evt.mouseButton.y);
                }
                else if (evt.mouseButton.button == Mouse::Right) {
                    spriteCirculo.setTexture(texturaAzul);
                    spriteCirculo.setOrigin(texturaAzul.getSize().x / 2, texturaAzul.getSize().y / 2);
                    spriteCirculo.setPosition(evt.mouseButton.x, evt.mouseButton.y);
                }
            }
        }
        window.draw(spriteCirculo);
        window.display();
    }
    return 0;
}