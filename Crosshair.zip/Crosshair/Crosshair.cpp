#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
using namespace sf;

Texture texturaCrosshair;
Sprite spriteCrosshair;

int main() {

    Event evt;
    texturaCrosshair.loadFromFile("crosshair.png");
    spriteCrosshair.setTexture(texturaCrosshair);
    spriteCrosshair.setOrigin(64, 64);
    spriteCrosshair.setPosition(400, 300);

    RenderWindow App(VideoMode(800, 600), "Crosshair");

    App.setMouseCursorVisible(false);

    while (App.isOpen()){
        while (App.pollEvent(evt)) {
            switch (evt.type) {
            case Event::Closed:
                App.close();
                break;
            case Event::MouseMoved:
                spriteCrosshair.setPosition(evt.mouseMove.x, evt.mouseMove.y);
            }
        }
        App.clear();
        App.draw(spriteCrosshair);
        App.display();
    }
    return 0;
}
